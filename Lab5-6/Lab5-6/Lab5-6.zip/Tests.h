#pragma once
#include "Controller.h"

void runTests();
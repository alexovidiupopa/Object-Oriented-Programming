#pragma once

class Validator {

private: 

	bool validateTitle(char givenTitle[]);
	bool validateFilmedAt(char givenFilmedAt[]);
	bool validateCreationDate(char givenCreationDate[]);
	bool validateFootagePreview(char givenFootagePreview[]);
	bool validateAccessCount(int givenAccessCount);

public:

	bool validateData(char givenTitle[], char givenFilmedAt[], char givenCreationDate[], char givenFootagePreview[], int givenAccessCount);
};